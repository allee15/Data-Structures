#include <iostream>

using namespace std;

struct nod{
    int inf;
    nod* st, *dr;
};

void inserare(nod* &vf,int x)
{
    	if(vf != NULL)
    {
    	if(vf->inf == x)
        	return;
        else
        	if(vf->inf > x)
            	inserare(vf->st , x);
            else
            	inserare(vf->dr , x);
    }
    else
    {
    	vf = new nod;
        vf->inf = x;
        vf->st = NULL;
        vf->dr = NULL;
    }
}

void RSD(nod* p)
{
    if(p!=NULL)
    {
        cout<<p->inf<<" ";
        RSD(p->st);
        RSD(p->dr);
    }
}

void SRD(nod* p)
{
    if(p!=NULL)
    {

        SRD(p->st);
        cout<<p->inf<<" ";
        SRD(p->dr);
    }
}

void SDR(nod* p)
{
    if(p!=NULL)
    {

        SDR(p->st);

        SDR(p->dr);
        cout<<p->inf<<" ";
    }
}

int main()
{
    int n,x;
    cin>>n;
    nod* vf=NULL;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        inserare(vf,x);
    }

    RSD(vf);
    cout<<endl;
    SRD(vf);
    cout<<endl;
    SDR(vf);
    return 0;
}

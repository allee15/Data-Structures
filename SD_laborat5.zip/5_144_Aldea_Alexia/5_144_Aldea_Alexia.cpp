#include <iostream>

using namespace std;

struct nod
{
    int inf;
    nod* st, *dr;
};

void inserare(nod* &vf,int x)
{
    if(vf != NULL)
    {
        if(vf->inf == x)
            return;
        else if(vf->inf > x)
            inserare(vf->st, x);
        else
            inserare(vf->dr, x);
    }
    else
    {
        vf = new nod;
        vf->inf = x;
        vf->st = NULL;
        vf->dr = NULL;
    }
}

int cautare(nod* vf, int k, int q)
{
    if(vf== NULL)
        return 0;
    else
    {
        if (vf->inf>k && vf->inf>q)
            cautare(vf->st,k,q);
        else{
        if (vf->inf<k && vf->inf<q)
            cautare(vf->dr,k,q);
    }}
    return vf->inf;
}

int main()
{
    int n,x,k,q;
    cin>>n>>k>>q;
    nod* vf=NULL;
    for(int i=0; i<n; i++)
    {
        cin>>x;
        inserare(vf,x);
    }

    cout<<cautare(vf,k,q);
    return 0;
}


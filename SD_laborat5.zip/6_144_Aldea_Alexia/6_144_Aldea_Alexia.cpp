#include <iostream>
#include <fstream>

using namespace std;

struct nod{
    int inf, balance;
    nod* st, *dr;
};

int calcbalance(nod* p) {
    if (p==NULL)
        return 0;
    return p->st->balance - p->dr->balance;
}

void RSD(nod* p) ///afisare
{
    if(p!=NULL)
    {
       cout<<p->inf<<" ";
        RSD(p->st);
        RSD(p->dr);
    }
}

nod* rotatie_st (nod* p){
    nod* q = p->dr;
    nod* k = q->st;
    q->st = p;
    p->dr = k;
    if(p->st==NULL)
        if(p->dr==NULL)
         p->balance=1;
        else
            p->balance=p->dr->balance +1;
    else
        p->balance= max(p->st->balance, p->dr->balance) +1;

    if(q->st==NULL)
        if(q->dr==NULL)
         q->balance=1;
        else
            q->balance=q->dr->balance +1;
    else
        q->balance= max(q->st->balance, q->dr->balance) +1;

    return q;
}

nod* rotatie_dr (nod* q){
    nod* p = q->st;
    nod* k = p->dr;
    p->dr = q;
    q->st = k;
    if(q->st==NULL)
        if(q->dr==NULL)
         p->balance=1;
        else
            q->balance=q->dr->balance +1;
    else
        q->balance= max(q->st->balance, q->dr->balance) +1;

    if(p->st==NULL)
        if(p->dr==NULL)
         p->balance=1;
        else
            p->balance=p->dr->balance +1;
    else
        p->balance= max(p->st->balance, p->dr->balance) +1;

    return p;
}

nod* inserare(nod* vf,int x)
{
    	if(vf != NULL)
    {
    	if(vf->inf == x)
        	return NULL;
        else
        	if(vf->inf < x)
            	inserare(vf->st , x);
            else
            	inserare(vf->dr , x);
    }
    else
    {
    	vf = new nod;
        vf->inf = x;
        vf->st = NULL;
        vf->dr = NULL;
        vf->balance=1;
    }
    int c = calcbalance(vf);

        ///stanga-stanga
        if(c >1 && x<vf->st->inf)
            return rotatie_dr(vf);

        ///dreapta-dreapta
        if(c<-1 && x>vf->dr->inf)
            return rotatie_st(vf);

        ///stanga-dreapta
        if(c>1 && x>vf->st->inf)
            {
        vf->st = rotatie_st(vf->st);
        return rotatie_dr(vf);
    }
        ///dreapta-stanga
        if(c<-1 && x<vf->dr->inf)
            {
        vf->dr = rotatie_dr(vf->dr);
        return rotatie_st(vf);
    }
}

int main()
{
    int x;
    ifstream f("arbore.in");
    nod* vf=NULL;
    while(f>>x)
    {
       vf= inserare(vf,x);
    }

    RSD(vf);

    return 0;
}

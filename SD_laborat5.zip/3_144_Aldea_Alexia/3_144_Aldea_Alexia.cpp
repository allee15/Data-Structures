#include <iostream>

using namespace std;

struct nod{
    int inf;
    nod* st, *dr;
};

void inserare(nod* &vf,int x)
{
    	if(vf != NULL)
    {
    	if(vf->inf == x)
        	return;
        else
        	if(vf->inf > x)
            	inserare(vf->st , x);
            else
            	inserare(vf->dr , x);
    }
    else
    {
    	vf = new nod;
        vf->inf = x;
        vf->st = NULL;
        vf->dr = NULL;
    }
}

void RSD(nod* p,int k1, int k2) ///afisare
{
    if(p!=NULL)
    {
        if(p->inf >= k1 && p->inf<=k2)
            cout<<p->inf<<" ";
        RSD(p->st,k1,k2);
        RSD(p->dr,k1,k2);
    }
}

int main()
{
    int n,x, k1, k2;
    cin>>n>>k1>>k2;
    nod* vf=NULL;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        inserare(vf,x);
    }

    RSD(vf,k1,k2);

    return 0;
}

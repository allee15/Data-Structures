#include <iostream>
#include <cstring>

using namespace std;

struct nod{
    char inf[10];
    nod* st, *dr;
};

void inserare(nod* &vf,char x[10])
{
    	if(vf != NULL)
    {
        	if(strlen(vf->inf)>strlen(x))
            	inserare(vf->st,x);
            else
            	inserare(vf->dr,x);
    }
    else
    {
    	vf = new nod;
        strcpy(vf->inf,x);
        vf->st = NULL;
        vf->dr = NULL;
    }
}

void SRD(nod* p) ///afisare
{
    if(p!=NULL)
    {
        SRD(p->st);
        cout<<p->inf<<" ";
        SRD(p->dr);
    }
}


int main()
{

     char n[256], *l;
    cin.get(n,256);
    nod* vf=NULL;
    l=strtok(n," ");
    while(l)
    {
        inserare(vf,l);
        l=strtok(NULL," ");
    }

    SRD(vf);

    return 0;
}

#include <iostream>

using namespace std;

struct nod{
    int inf;
    nod* st, *dr;
};

void inserare(nod* &vf,int x)
{
    	if(vf != NULL)
    {
    	if(vf->inf == x)
        	return;
        else
        	if(vf->inf > x)
            	inserare(vf->st , x);
            else
            	inserare(vf->dr , x);
    }
    else
    {
    	vf = new nod;
        vf->inf = x;
        vf->st = NULL;
        vf->dr = NULL;
    }
}

void sterge2(nod* &p, nod* &q) ///q treb sters, cu p identificam nodul cel mai din dreapta
{
    if(p->dr)
        sterge2(p->dr,q);
    else
    {
        q->inf=p->inf;
        nod* val=p;
        p=p->st;
        delete val;
    }
}

void sterge(nod * &p , int x)
{
    if(p != NULL)
    {
        if(p->inf==x)
        { ///il stergem
            if(p->st==NULL&&p->dr==NULL)
            {delete p;
                p = NULL;}
            else
                if(p->dr==NULL)
                {nod *q= p;
                    p = p->st;
                    delete q;}
                else
                    if(p->st==NULL)
                    {nod *q= p;
                        p = p->dr;
                        delete q;}
                    else
                        sterge2(p->st,p);
        }
        else
            if(p->inf>x) sterge(p->st,x);
            else sterge(p->dr,x);
    }
    else ///x nu e in arbore
        return;
}

void RSD(nod* p) ///afisare
{
    if(p!=NULL)
    {
        cout<<p->inf<<" ";
        RSD(p->st);
        RSD(p->dr);
    }
}

int main()
{
    int n,x,y;
    cin>>n>>x;;
    nod* vf=NULL;
    for(int i=0;i<n;i++)
    {
        cin>>y;
        inserare(vf,y);
    }

    sterge(vf,x);
    RSD(vf);
    return 0;
}

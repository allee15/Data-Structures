#include <iostream>

using namespace std;

int main()
{
    int n,m, a[100],x;
    cin>>n>>m;
    for(int i=0; i<n; i++)
        cin>>a[i];
    for(int i=0; i<m; i++)
    {
        cin>>x;
        int ok=0;
        for(int j=0; j<n; j++)
            if(x<=a[j])
            {
                for(int k=n-1; k>=j;k--)
                    a[k+1] = a[k];
                a[j] = x;
                n ++;
                ok=1;
                break;
            }
        if(ok==0)
            a[n++]=x;
    }
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";
        return 0;
    }

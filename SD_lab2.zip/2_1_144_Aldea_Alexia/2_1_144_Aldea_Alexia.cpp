#include <iostream>

using namespace std;
// min-heap
int n, v[100];

void combinare(int vf,int n)
{
    //formam un MinHeap dintr-un varf si 2 MinHeapuri
    int baza=2*vf, valoare=v[vf], ok=0;
    while(baza<=n && ok==0)
    {
        if (baza<n && v[baza]>v[baza+1])
            baza++;
        if (valoare>v[baza])
        {
            v[vf]=v[baza];
            vf=baza;
            baza=2*baza;
        }
        else
            ok=1;
    }
    v[vf]=valoare;
}

void heap()
{
    //organizam vectorul ca un MinHeap
    for(int i=n/2;i>=1;i--)
        combinare(i,n);
}

void heapsort()
{
    heap();
    for(int i=n;i>=2;i--)
    {
        swap(v[1],v[i]);
        combinare(1,i-1);
    }
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i];
    heapsort();
    for(int i=1;i<=n;i++)
        cout<<v[i]<<" ";
    return 0;
}

#include <iostream>

using namespace std;

int n,v[100];

int partitionare(int st,int dr)
{

    int i=st,j=dr,di=0,dj=1;

    while(i<j)
    {

        if (v[i]<v[j])
        {
            swap(v[i],v[j]);
            swap(di,dj);
        }

        i=i+di;
        j=j-dj;
    }

    return j;

}

void qs(int st,int dr)
{
    if (st<dr)
    {
        int pivot=partitionare(st,dr);

        qs(st,pivot-1);

        qs(pivot+1,dr);

    }

}

int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
        cin>>v[i];
    qs(1,n);
    for(int i=1; i<=n; i++)
        cout<<v[i]<<" ";
    return 0;
}

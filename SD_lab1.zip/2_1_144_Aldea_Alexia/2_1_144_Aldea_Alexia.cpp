#include <iostream>

using namespace std;

int main()
{
    int n,x;
    cin>>n>>x;
    int v[n];
    for(int i=0;i<n;i++)
        cin>>v[i];
    int ok=0;
    for(int i=0;i<n;i++)
        if(v[i]==x)
            ok=1;
    if(ok==1)
        cout<<"elementul exista in sir";
    else
        cout<<"elementul nu exista in sir";
    return 0;
}

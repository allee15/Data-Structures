#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int v[n];
    for (int i=0; i<n; i++)
        cin>>v[i];
    int sortat=0;
    while(sortat==0)
    {
        sortat=1;
        for(int i=0; i<n-1; i++)
            if(v[i]>v[i+1])
            {
                swap(v[i],v[i+1]);
                sortat=0;
            }
    }
    for(int i=0;i<n;i++)
        cout<<v[i]<<" ";
    return 0;
}

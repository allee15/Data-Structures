#include <iostream>

using namespace std;

int main()
{
    int n,x;
    cin>>n>>x;
    int v[n];
    for(int i=1;i<=n;i++)
        cin>>v[i];
    int st=1, dr=n, poz=0;
    while(st<=dr && poz==0)
    {
        int m=(st+dr)/2;
        if(v[m]==x)
            poz=m;
        else
        {
            if(v[m]<x)
                st=m+1;
            else
                dr=m-1;
        }
    }
    if(poz!=0)
        cout<<"elementul exista in sir";
    else
        cout<<"elementul nu exista in sir";
    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    int n,x,ok=-1;
    cin>>n>>x;
    int v[n];
    for(int i=0; i<n; i++)
    {
        cin>>v[i];
        if(x==v[i])
            ok=i;
    }
    if(ok!=-1)
        cout<<ok;
    else
        cout<<"elementul nu exista in sir";
    return 0;
}

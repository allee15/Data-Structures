#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int v[n];
    for(int i=0;i<n;i++)
        cin>>v[i];
    for(int i=1;i<n;i++)
    {
        int j=i;
        while(j>0 && v[j-1]>v[j])
        {
            int c=v[j];
            v[j]=v[j-1];
            v[--j]=c;
        }
    }
    for(int i=0;i<n;i++)
        cout<<v[i]<<" ";
    return 0;
}

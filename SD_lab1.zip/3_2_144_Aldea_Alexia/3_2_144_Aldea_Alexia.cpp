#include <iostream>

using namespace std;

int main()
{
    int n,x,y;
    cin>>n;
    int a[n][2];
    for(int i=0; i<n; i++)
    {
        cin>>x>>y;
        a[i][0]=x;
        a[i][1]=y;
    }

    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
            if(a[i][0]>a[j][0])
                {int aux1=a[i][0], aux2=a[i][1];
                a[i][0]=a[j][0]; a[i][1]=a[j][1];
                a[j][0]=aux1; a[j][1]=aux2;}
            else
            {
                if(a[i][0]==a[j][0])
                    if(a[i][1]>a[j][1])
                        {int aux1=a[i][0], aux2=a[i][1];
                a[i][0]=a[j][0]; a[i][1]=a[j][1];
                a[j][0]=aux1; a[j][1]=aux2;}
            }

    int s=0;
    for(int i=1;i<n;i++)
        if(a[i][0]>a[i-1][0] || (a[i][0]==a[i-1][0] && a[i][1]>a[i-1][1]))
            s++;
    cout<<s;
    return 0;
}

#include <iostream>
#include <string>

using namespace std;

struct nod{
    int inf;
    string info;
    nod* adr;
}*vf;

void inserare(int x, string y)
{
    nod* p= new nod;
    p->inf=x%11;
    p->info=y;
    p->adr= NULL;
    if( vf == NULL)
    {
        vf=p;
    }
}

void afisare()
{
    nod* p= vf;
    while (p!=NULL)
    {
        cout<<p->inf<<" "<<p->info<<endl;
        p=p->adr;
    }
}

int main()
{
    int n,x;
    string y;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x>>y;
        inserare(x,y);
    }
    afisare();

    return 0;
}

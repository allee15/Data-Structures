#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    int n;
    char s[256];
    cin>>n;
    if(n%10<5 )
    {
        if(n%10==4)
            strcpy(s,"IV");
        else
        {
            int o=n%10;
            o--;
            strcpy(s,"I");
            while(o>0)
            {
                strcat(s,"I");
                o--;
            }
        }
    }
    else
    {
        if(n%10 >=5 && n%10<9)
        {
            strcpy(s,"V");
            int o=n%10;
            o -=5;

            while(o>0)
            {
                strcat(s,"I");
                o --;
            }
        }
        else
        {
            if(n%10==9)
                strcpy(s,"IX");
        }
    }

    n/=10;
    n=n*10;
    if(n%100==10)
        strcat(s,"X");
    else
    {
        if(n%100==20)
            strcat(s,"XX");
        else if(n%100==30)
            strcat(s,"XXX");
        else if(n%100==40)
            strcat(s,"XL");
    }
    if(n%100>=50 && n%100<90)
    {
        strcat(s,"K");
        int x=n%100/10;
        x=x-5;
        while(x>0)
        {
            strcat(s,"X");
            x--;
        }
    }
    if(n%100==90)
        strcat(s,"XC");

    n=n/100;
    n=n*100;
    if(n%1000==100)
        strcat(s,"C");
    else
    {
        if(n%1000==200)
            strcat(s,"CC");
        else if(n%1000==300)
            strcat(s,"CCC");
        else if(n%1000==400)
            strcat(s,"CD");
    }
    if(n%1000>=500 && n%1000<900)
    {
        strcat(s,"D");
        int x=n%1000/100;
        x=x-5;
        while(x>0)
        {
            strcat(s,"C");
            x--;
        }
    }
    if(n%1000==900)
        strcat(s,"CM");

    n=n/1000;
    n=n*1000;
    if(n%10000==1000)
        strcat(s,"M");;

        if(n%10000==2000)
            strcat(s,"MM");
        else if(n%10000==3000)
            strcat(s,"MMM");

    for(int i=strlen(s)-1;i>=0;i--)
        cout<<s[i];
    return 0;
}

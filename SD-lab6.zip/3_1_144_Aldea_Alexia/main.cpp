#include <iostream>
#include <cstring>
#include <stdlib.h>

using namespace std;

int main()
{
    char digits[256];
    cin.get(digits,256);
    for(int i=0;i<strlen(digits)-1;i++)
    {
        int x=digits[i]-'0';
        for(int j=i+1;j<strlen(digits);i++)
        {
            int y=digits[j]-'0';
            char a= 'a'+x-2, b='b'+y-1;
            cout<<a<<b<<", ";
             a= 'a'+x-2; b='b'+y;
            cout<<a<<b<<", ";
             a= 'a'+x-2; b='b'+y+1;
            cout<<a<<b<<", ";

             a= 'a'+x-1; b='b'+y-1;
            cout<<a<<b<<", ";
            a= 'a'+x-1; b='b'+y;
            cout<<a<<b<<", ";
            a= 'a'+x-1; b='b'+y+1;
            cout<<a<<b<<", ";

             a= 'a'+x; b='b'+y-1;
            cout<<a<<b<<", ";
            a= 'a'+x; b='b'+y;
            cout<<a<<b<<", ";
            a= 'a'+x; b='b'+y+1;
            cout<<a<<b<<", ";
        break;
        }

    }

    return 0;
}

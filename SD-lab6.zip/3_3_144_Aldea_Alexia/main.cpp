#include <iostream>
#include <cstring>

using namespace std;

void cv(char s[256])
{
    char c[256];
    int x=0;
    for(int i=0;i<strlen(s);i++)
           if(s[i]== 'A' || s[i]=='C' || s[i]=='G' || s[i]=='T')
           { if(x<10)
                if(x==0){
                    strcpy(c,s[i]); x++;
                }
                  else {strcat(c,s[i]); x++;}
                else
                {cout<<c<<" ";
                    x=0;}
            }
}

int main()
{
    char s[256];
    cin.get(s,256);
    cv(s);


    return 0;
}

#include <iostream>

using namespace std;

struct nod
{
    int info;
    nod* adr;
};

void push_s(nod* &vf,int x)
{
    nod* p=new nod;
    p->info=x;
    p->adr=vf;
    vf=p;
}

int pop_s(nod* &vf, int &x)
{
    if(vf==NULL)
        return 0;
    else
    {
        x=vf->info;
        nod*p=vf;
        vf=vf->adr;
        delete p;
        return 1;
    }
}

int main()
{
    int m,x=0;
    cin>>m;
    int v[100][100],c=2;
    for(int i=1; i<=m; i++)
        for(int j=1; j<=m; j++)
            cin>>v[i][j];

    nod* vf=NULL;
    for(int i=1; i<=m; i++)
        for(int j=1; j<=m; j++)
            if(v[i][j]==1)
            {
                x++;
                if(v[i+1][j]==1 || v[i][j-1]==1 || v[i][j+1]==1 || (i>1 && v[i-1][j]==1))
                    push_s(vf,c);
                else
                    c++;
            }

    int s=0;
    while(pop_s(vf,c)==1)
        s++;
        if(s==x)
            cout<<"Da";
        else
            cout<<"Nu";

    return 0;
}

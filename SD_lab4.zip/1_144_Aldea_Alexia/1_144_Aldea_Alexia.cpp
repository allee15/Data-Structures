#include <fstream>
#include <iostream>

using namespace std;

struct nod{
    int info, prioritate;
    nod* adr;
};
void push_c( nod* &vf, int x, int y){
    nod* inceput = vf;
    nod* aux;
    aux = new nod;
    aux->info = x;
    aux->prioritate = y;
    if (vf->prioritate > y){
        //se inseraza inainte
        aux->adr = vf;
        vf = aux;
    }
    else {
        //se traverseaza lista deja creata pana i se gaseste lui aux locul potrivit
        while (inceput->adr != NULL && inceput->adr->prioritate < y)
            inceput = inceput->adr;
        aux->adr = inceput->adr;
        inceput->adr = aux;
    }
}
void afisare_stiva (nod *vf){
    cout << endl;
    while (vf){
        cout << vf->info << " " << vf->prioritate << endl;
        vf = vf->adr;
    }
    cout << endl;
}
void pop_c(nod* &vf, int &x, int &y)
{
    if(vf!=NULL)
    {
        nod* p =vf;
        x=vf->info;
        y=vf->prioritate;
        vf=vf->adr;
        delete p;
    }
}

int main()
{
    int x,y,a,b;
    nod* vf;
    //creare stiva
    ifstream f("date.in");
    //creare varf
    f>>x>>y;
    vf = new nod;
    vf->info = x;
    vf->prioritate = y;
    vf->adr=NULL;
    //citire rest valori
    while(f>>x>>y){
        push_c(vf,x,y); //cout<<x<<" "<<y<<endl;
    }
    f.close();
    //verificare - creare corecta a listei de prioritati
    afisare_stiva(vf);

    while (vf){
        cout << vf->info << " " << vf->prioritate << endl;
        pop_c(vf, vf->info, vf->prioritate);
    }
    return 0;
}

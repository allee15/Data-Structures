#include <iostream>

using namespace std;

struct nod{
    int info;
    nod* adr;
};

void push_s(nod* &vf,int x)
{
    nod* p=new nod;
    p->info=x;
    p->adr=vf;
    vf=p;
}

int pop_s(nod* &vf, int &x)
{
    if(vf==NULL)
        return 0;
    else
    {
        x=vf->info;
        nod*p=vf;
        vf=vf->adr;
        delete p;
        return 1;
    }
}

int main()
{
    int n; cin>>n;
    int v[n],c=0;
    for(int i=1;i<=n;i++)
        cin>>v[i];

    nod* vf=NULL;
    for(int i=1;i<n;i++)
        for(int j=i+1;j<=n;j++)
            if(v[i]==v[j])
                if((j-i)%2!=0)
                    {push_s(vf,v[i]); c=v[i];}
    int s=0;
    while(pop_s(vf,c)==1)
            s++;
    if(s==n/2)
        cout<<"Da";
    else
        cout<<"Nu";

    return 0;
}

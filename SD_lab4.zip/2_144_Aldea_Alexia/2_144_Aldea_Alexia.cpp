#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <stack>
using namespace std;

struct nod
{
    char info;
    nod* adr;
};
void push(nod*& vf, char x)
{
    nod* p = new nod;
    p->info = x;
    p->adr = vf;
    vf = p;
}

int pop(nod*& vf)
{
    bool ok = 0;
    int x;
    if (vf != NULL){
        x = vf->info;
        ok=1;
    }
    nod* p = vf;
    vf = vf->adr;
    delete p;
    if ( ok == 1)
        return x;
    else
        return 0;
}

int calcul (string s){
    nod* numere;
    nod* semne;
    int suma = 0, numar = 0;
    int semn = 1, i;
    for (i=0; i<s.size(); i++){
        if (isdigit(s[i])){
            while (i<s.size() && isdigit(s[i])){
                numar = numar*10 + (s[i] - '0');
                i++;
            }
            i--;
            //adaugare la suma totala
            suma += numar*semn;
            //resetare variabile
            semn = 1;
            numar = 0;
        }
        else {
            //este semn
            if (s[i] == '('){
                //se adauga suma deja calculata / semn la stiva
                push(numere, suma);
                push(semne, semn);
                //resetare variabile
                semn = 1;
                numar = 0;
            }
            else
                if (s[i] == '+')
                    semn = 1;
                else
                    if (s[i] == '-')
                        semn *= (-1);
                    else
                        if (s[i] == ')'){
                            //se adauga la suma totala ce era deja in stiva
                            suma = suma*pop(semne)+pop(numere);
                        }
                        else
                            // pt empty spaces
                            continue;
        }
    }
    return suma;
}

int main()
{
    cout << calcul("(1+(4+5+2)-3)+(6+8)") << endl;
    return 0;
}

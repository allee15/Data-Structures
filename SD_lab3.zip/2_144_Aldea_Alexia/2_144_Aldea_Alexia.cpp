#include <iostream>
using namespace std;

struct nod
{
    int info;
    nod * adr;
}*l1, *l2;

void inserare(nod **l, int x)
{
    nod *s=new nod;
    s->info=x;
    if(l==NULL)
    {
        *l=s;
    }
    else
    {
        s->adr=*l;
        *l=s;
    }
}

nod* insumeaza(nod *a, nod *b)
{
    nod* l;
    inserare(&l,-1);
    int c=0;
    while(a!=NULL && b!=NULL)
    {
        int aux=a->info+c+b->info;
        inserare(&l,aux%10);
        c=aux/10;
        a=a->adr;
        b=b->adr;
    }

    while(a!=NULL)
    {
        int aux=a->info+c;
        inserare(&l,aux%10);
        c=aux/10;
        a=a->adr;
    }
    while(b!=NULL)
    {
        int aux=b->info+c;
        inserare(&l,aux%10);
        c=aux/10;
        b=b->adr;
    }
    if(c>0)
    {
        inserare(&l,c);
    }
    return l;
}

int main()
{
    inserare(&l1,9);
    inserare(&l1,2);
    inserare(&l1,3);

    inserare(&l2,9);
    inserare(&l2,2);
    inserare(&l2,5);
    inserare(&l2,1);
    nod*x=insumeaza(l1,l2);
    while(x->info!=-1)
    {
        cout<<x->info;
        x=x->adr;
    }
    return 0;
}

#include <iostream>
#include <cmath>

using namespace std;

struct nod {
    float grade, coef, info;
    nod* next;
};

void inserare(int x, int y, nod* vf)
{
    nod* p = new nod;
    p->coef = x;
    p->grade = y;
    p->next = NULL;
    if (vf == NULL)
    {
        vf = p;
    }
}

void afisare(nod* vf)
{
    nod* p = vf;
    while (p != NULL)
    {
        cout <<p->grade<<"*"<< p->coef << " ";
        p = p->next;
    }
}

void Ex3_1(nod* vf, float a)
{
    nod* p = vf;
    while (p != NULL)
    {
        p->coef= p->coef *a;
        p = p->next;
    }
    afisare(p);
}

void Ex3_2(nod* vf, float x0)
{
    nod* p = vf;
    while (p != NULL)
    {
        float k = pow(x0, p->grade);
        k = k * p->coef;
        p->info = k;
        p = p->next;
    }
    afisare(p);
}

void Ex3_3(nod* vf1, nod* vf2)
{
    nod* p1 = vf1;
    nod* p2 = vf2;
    while (p1 != NULL && p2 != NULL)
    {
        if (p1->grade == p2->grade)
        {
            p1->coef = p1->coef + p2->coef;
        }
        p1 = p1->next;
        p2 = p2->next;
    }
    afisare(p1);
}

int main()
{
    nod* vf1 = new nod;
    nod* vf2 = new nod;
    int n, m;
    float x,y;
    float a;
    cin >> n >> m;
    for(int i=0;i<n;i++)
    {
        cin >> x >> y;
        inserare(x, y, vf1);
    }
    for (int i = 0;i < m;i++)
    {
        cin >> x >> y;
        inserare(x, y,vf2);
    }
    cin >> a;
    Ex3_1(vf1, a);
    float x0;
    cin >> x0;
    Ex3_2(vf1, x0);
    Ex3_3(vf1, vf2);
    return 0;
}

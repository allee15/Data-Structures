#include <iostream>

using namespace std;

struct nod
{
    int info;
    nod * adr;
}*vf,*sf;

void inserare(int x)
{
    nod* p= new nod;
    p->info=x;
    p->adr= NULL;
    if( vf == NULL)
    {
        vf=sf=p;
    }
    else
    {
        sf->adr=p;
        sf=p;
    }
}

void afisare()
{
    nod* p= vf;
    while (p!=NULL)
    {
        cout<<p->info<<" ";
        p=p->adr;
    }
}

void ordonare()

{
    nod *p;
    int ord,aux;
    do
    {
        p=vf;
        ord=1;
        while(p->adr)
        {
            if(p->info > p->adr->info)
            {
                aux=p->info;
                p->info=p->adr->info;
                p->adr->info=aux;
                ord=0;
            }
            p=p->adr;
        }

    }

    while(ord==0);

}

void stergere(nod* q, nod* p)
{
    if(vf==p)
    {
        vf=vf->adr;
        delete p;
    }
    else if(p==sf)
    {
        q->adr=NULL;
        sf=q;
        delete p;
    }
    else
    {
        q->adr=p->adr;
        delete p;
    }

}

void stergereElem(int k)

{
    nod *p,*q; ///il stergem pe q
    p=vf;
    if(vf->info==k)
    {
        q=vf;
        vf=vf->adr;
        delete q;
    }
    else
    {
        while(p->adr->info!=k &&p)
            p=p->adr;
        q=p->adr;
        p->adr=q->adr;
        if(q==sf)
            sf=q;
        delete q;
    }
}

void Ex1_1()
{
    int n,x;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        inserare(x);
    }
    ordonare();
    afisare();
}

void Ex1_2()
{
    int n,x;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        inserare(x);
    }
    while( vf !=NULL )
        stergere(sf,vf);
    afisare();
}

void Ex1_3()
{
    int n,x,k;
    cin>>n>>k;
    for(int i=1; i<=n; i++)
    {
        cin>>x;
        inserare(x);
    }
    stergereElem(k);
    afisare();
}

int main()
{
    ///Ex1_1();
    ///Ex1_2();
    ///Ex1_3();
    return 0;
}
